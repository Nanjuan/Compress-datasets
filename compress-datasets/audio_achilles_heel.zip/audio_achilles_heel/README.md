---
dataset_info:
  features:
  - name: audio
    dtype: audio
  splits:
  - name: train
    num_bytes: 44848962.0
    num_examples: 350
  download_size: 41424793
  dataset_size: 44848962.0
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
---
