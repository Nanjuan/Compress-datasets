---
dataset_info:
  features:
  - name: agentname
    dtype: string
  - name: description
    dtype: string
  - name: systemprompt
    dtype: string
  - name: chatgptlink
    dtype: string
  - name: json-schema
    dtype: string
  - name: is-agent
    dtype: bool
  - name: is-single-turn
    dtype: string
  configs:
  - config_name: default
    data_files:
    - split: train
      path: prompts.json
  download_size: 2281040
  dataset_size: 2281040
task_categories:
- text-generation
language:
- en
tags:
- system-prompts
- ai-agents
- prompt-engineering
- conversational-ai
- llm
- chatgpt
license: mit
size_categories:
- 100<n<1K
---

# System Prompts Dataset - August 2025

**Point-in-time export from Daniel Rosehill's system prompt library as of August 3rd, 2025**

## Overview

This repository contains a comprehensive collection of 944 system prompts designed for various AI applications, agent workflows, and conversational AI systems. While many of these prompts now serve as the foundation for more complex agent-based workflows, they continue to provide essential building blocks for AI system design and implementation.

## Dataset Structure

The dataset is provided as a single JSON file (`prompts.json`) containing:

- **944 unique system prompts** covering diverse use cases
- Structured metadata including generation timestamp and source information
- Detailed prompt descriptions and categorization
- Links to associated ChatGPT implementations where applicable
- Agent workflow indicators and configuration flags

### JSON Schema

Each prompt entry contains:

```json
{
  "agentname": "Descriptive name for the prompt/agent",
  "description": "Brief description of the prompt's purpose",
  "systemprompt": "The actual system prompt text",
  "chatgptlink": "URL to ChatGPT implementation (if available)",
  "json-schema": "Associated JSON schema (if applicable)",
  "is-agent": "Boolean indicating if this is part of an agent workflow",
  "is-single-turn": "Boolean indicating conversation type"
}
```

## Use Cases

### Foundation for Agent Workflows
Many prompts in this collection serve as the base layer for sophisticated agent-based systems, providing:
- Initial system context and behavior definition
- Role-specific instructions for specialized agents
- Consistent interaction patterns across agent networks

### Direct Implementation
Prompts can be used directly for:
- Conversational AI systems
- Task-specific AI assistants
- Content generation workflows
- Analysis and processing pipelines

### Research and Development
- Prompt engineering research
- AI behavior analysis
- System prompt effectiveness studies
- Comparative AI system development

## Categories Covered

The collection spans numerous domains including:
- Task management and productivity
- Content creation and editing
- Technical assistance and coding
- Analysis and research support
- Creative and artistic applications
- Business and professional workflows
- Educational and training scenarios

## Usage

### Loading the Dataset

```python
import json

with open('prompts.json', 'r') as f:
    data = json.load(f)
    
prompts = data['prompts']
metadata = data['metadata']

print(f"Total prompts: {metadata['total_prompts']}")
```

### Filtering by Type

```python
# Get agent-based prompts
agent_prompts = [p for p in prompts if p.get('is-agent', False)]

# Get single-turn prompts
single_turn = [p for p in prompts if p.get('is-single-turn') == 'true']
```

## Dataset Metadata

- **Generated**: August 3rd, 2025
- **Total Prompts**: 944
- **Format**: JSON
- **Source**: Daniel Rosehill's system prompt library
- **License**: [Please specify license]

## Evolution and Context

This dataset represents a snapshot of an actively maintained system prompt library. While the AI landscape continues to evolve toward more sophisticated agent-based architectures, these foundational prompts remain valuable for:

1. **Rapid prototyping** of new AI applications
2. **Educational purposes** in prompt engineering
3. **Baseline establishment** for AI system behavior
4. **Component reuse** in larger agent frameworks

## Contact

For questions, feedback, or collaboration opportunities:

- **Website**: [danielrosehill.com](https://danielrosehill.com)
- **Email**: [public@danielrosehill.com](mailto:public@danielrosehill.com)

---

*This dataset reflects the state of system prompt development as of August 3rd, 2025, and serves as both a practical resource and a historical snapshot of AI prompt engineering practices.*
